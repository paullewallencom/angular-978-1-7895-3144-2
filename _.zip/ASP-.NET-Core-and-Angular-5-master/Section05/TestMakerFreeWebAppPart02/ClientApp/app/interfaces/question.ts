interface Question {
    Id: number;
    QuizId: number;
    Text: string;
}
